C.Dalid at Projectplace.com, 2013

The purpose of Projectplace API is to provide programmatic access
to all core functionality of Projectplace.com. The API does not yet
cover all functionality but the coverage is continously expanding.
Since our customers pay for using our service we belive that we should
provide them with the option to build ontop of it to further boost
productivity, reliability and efficiency in their processes.

This library provide the basic infrastructure required to access the
functionality: General request and authentication handling.